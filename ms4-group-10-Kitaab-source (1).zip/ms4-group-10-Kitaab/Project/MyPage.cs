﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Project
{
	public class MyPage : ContentPage
	{
		List<Books> books;
		TapGestureRecognizer logoTap = new TapGestureRecognizer();
		TapGestureRecognizer iconTap = new TapGestureRecognizer();
		TapGestureRecognizer accountsettingtab = new TapGestureRecognizer();
		TapGestureRecognizer addbookstab = new TapGestureRecognizer();
		ViewModel vm;
		Label gotoAddABookPage;
		Label gotoAccountSettingsPage;
		Label welcome;
		int tapcount = 0;
		StackLayout booksStack;
		public MyPage(List<Books> userBooks, ViewModel viewmodel)
		{
			vm = viewmodel;
			books = userBooks;
			logoTap.Tapped += OnLogoTapGestureRecognizerTapped;
			iconTap.Tapped += OnIconTapGestureRecognizerTapped;
			accountsettingtab.Tapped += OnAccountSettingsTapGestureRecognizerTapped;
			addbookstab.Tapped += OnAddBooksTapGestureRecognizerTapped;

			StackLayout outerStack = new StackLayout
			{
				Spacing = 20,
				Padding = new Thickness(0, Device.OnPlatform(30, 10, 10), 0, 0),
			};
			StackLayout optionsTab = new StackLayout
			{
				BackgroundColor = Color.FromHex("660000"),

			};
			StackLayout navBarStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};
			Image logo = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};

			Uri imageUrl = new Uri("http://etc.usf.edu/presentations/extras/letters/varsity_letters/14/23/k-400.png");
			logo.Source = ImageSource.FromUri(imageUrl);
			logo.GestureRecognizers.Add(logoTap);

			Label nothing = new Label
			{
				Text = " ",
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};
			Image mybooksIcon = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri myBooks = new Uri("http://newsroom.uber.com/wp-content/uploads/2014/07/person-icon.png");
			mybooksIcon.Source = ImageSource.FromUri(myBooks);
			mybooksIcon.GestureRecognizers.Add(iconTap);
			navBarStack.Children.Add(logo);
			navBarStack.Children.Add(nothing);
			navBarStack.Children.Add(mybooksIcon);
			optionsTab.Children.Add(navBarStack);

			//--nav bar section ends here----------------------------------

			//The following label appears only when icon is tapped 
			//They vanish when the icon is tapped again
			gotoAddABookPage = new Label
			{
				Text = "Add a Book",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
				FontFamily = Device.OnPlatform(
					"serif",
					"serif",
					"serif"
					),
				TextColor = Color.FromHex("cccccc"),
				IsVisible = false
			};
			gotoAddABookPage.GestureRecognizers.Add(addbookstab);
			gotoAccountSettingsPage = new Label
			{
				Text = "Account Settings",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
				FontFamily = Device.OnPlatform(
					"serif",
					"serif",
					"serif"
					),
				TextColor = Color.FromHex("cccccc"),
				IsVisible = false
			};
			gotoAccountSettingsPage.GestureRecognizers.Add(accountsettingtab);

			optionsTab.Children.Add(gotoAddABookPage);
			optionsTab.Children.Add(gotoAccountSettingsPage);
			outerStack.Children.Add(optionsTab);
			//navigation labels end here-----------------------------------

			welcome = new Label
			{
				Text = "",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
				FontFamily = Device.OnPlatform(
					"serif",
					"serif",
					"serif"
					),
				TextColor = Color.FromHex("660000"),
			};
			if (userBooks.Count == 0)
			{
				welcome.Text = "You don't have any books on sale!";
			}
			else
			{
				welcome.Text = "Your books on sale.";
			}
			outerStack.Children.Add(welcome);
			booksStack = new StackLayout
			{
				Spacing = 20,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.FillAndExpand

			};
			foreach (var b in books)
			{
				StackLayout innerStack = addstack(b);
				booksStack.Children.Add(innerStack);
			}

			outerStack.Children.Add(new ScrollView
			{
				Content = booksStack
			});


			Image backgroundImage = new Image
			{
				Aspect = Aspect.Fill
			};
			backgroundImage.Source = ImageSource.FromUri(new Uri("http://www.topiphone5wallpapers.com/wp-content/uploads/Background/White%202.jpg"));

			var relativeLayout = new RelativeLayout();

			relativeLayout.Children.Add(backgroundImage,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			relativeLayout.Children.Add(outerStack,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			Content = relativeLayout;
		}


		//new functions starts here

		StackLayout addstack(Books b)
		{

			StackLayout buttonsStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions= LayoutOptions.CenterAndExpand
			};

			StackLayout outer = new StackLayout
			{
				Orientation = StackOrientation.Vertical,
			};
			StackLayout titlePriceStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
			};
			var layout = new StackLayout
			{
				Padding = new Thickness(5, 5, 5, 5),
				Spacing = 10,
			//	BackgroundColor = Color.FromHex("600303"),
				HorizontalOptions = LayoutOptions.Center,
			};

			var coverImage = new Image
			{

				Aspect = Aspect.AspectFit,
				HeightRequest = 200,

			};
			Uri imageUrl = new Uri(b.path);
			coverImage.Source = ImageSource.FromUri(imageUrl);

			Label titleLabel = new Label
			{
				Text = b.name,
				HorizontalTextAlignment = TextAlignment.Center,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.FromHex("600303"),

			};

			Label priceLabel = new Label
			{
				Text = "$"+b.price,
				HorizontalTextAlignment = TextAlignment.Center,
				TextColor = Color.FromHex("600303"),
			};

			Button removeButton = new Button
			{
				Text = " Remove  ",
				TextColor = Color.FromHex("f2f2f2"),
				FontSize = 15,

				FontFamily = Device.OnPlatform(
					"null",
					"serif",
					"serif"
					),
				BackgroundColor = Color.FromHex("600303"),
				StyleId = "" + b.id,
			};
			removeButton.Clicked += OnRemoveButtonClick;
			Button previewButton = new Button
			{
				Text = " Preview  ",
				TextColor = Color.FromHex("f2f2f2"),
				FontSize = 15,

				FontFamily = Device.OnPlatform(
					"null",
					"serif",
					"serif"
					),
				BackgroundColor = Color.FromHex("600303"),
				StyleId = "" + b.id

			};
			previewButton.Clicked += OnPreviewButtonClick;

			Button editButton = new Button
			{
				Text = " Edit  ",
				TextColor = Color.FromHex("f2f2f2"),
				FontSize = 15,

				FontFamily = Device.OnPlatform(
					"null",
					"serif",
					"serif"
					),
				BackgroundColor = Color.FromHex("600303"),
				StyleId = "" + b.id

			};
			editButton.Clicked += OneditButtonClicked;

			layout.Children.Add(coverImage);
			titlePriceStack.Children.Add(titleLabel);
			titlePriceStack.Children.Add(priceLabel);
			buttonsStack.Children.Add(previewButton);
			buttonsStack.Children.Add(editButton);
			buttonsStack.Children.Add(removeButton);
			layout.Children.Add(titlePriceStack);
			outer.Children.Add(layout);
			outer.Children.Add(buttonsStack);
			return outer;
		}

		void OnLogoTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new BooksSellingPage(vm.booksOnSale, vm));
		}
		void OnIconTapGestureRecognizerTapped(object sender, EventArgs args)
		{

			if (tapcount % 2 == 0)
			{
				gotoAddABookPage.IsVisible = true;
				gotoAccountSettingsPage.IsVisible = true;
			}
			else {
				gotoAddABookPage.IsVisible = false;
				gotoAccountSettingsPage.IsVisible = false;
			}
			tapcount++;
		}
		void OnAccountSettingsTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PushModalAsync(new AccountSettings(vm));
		}
		void OnAddBooksTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PushModalAsync(new AddABook(vm));

		}
		void OnPreviewButtonClick(object sender, EventArgs args)
		{
			var button = (Button)sender;
			int id = int.Parse(button.StyleId);
			vm.getBookPreview(id);
		}
		void OnRemoveButtonClick(object sender, EventArgs args)
		{
			var button = (Button)sender;
			int id = int.Parse(button.StyleId);
			books = vm.removeBook(id);
			booksStack.Children.Clear();
			foreach (var b in books)
			{
				StackLayout innerStack = addstack(b);
				booksStack.Children.Add(innerStack);
			}
		}
		void OneditButtonClicked(object sender, EventArgs arg) { 
			var button = (Button)sender;
			int id = int.Parse(button.StyleId);
			Books book = vm.getBook(id);
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new EditPage(vm, book));
		}
	}
}


