﻿using System;

using Xamarin.Forms;

namespace Project
{
	public class App : Application
	{
		const string login = "login";
		const string username = "usernmae";
		const string phone = "phone";
		const string choice = "choice";
		const string password = "password";
		public Boolean l { set; get; }
		public String u { set; get; }
		public Boolean c { set; get; }
		public String p { set; get; }
		public String pass { set; get; }
		public App()
		{
			if (Properties.ContainsKey(login))
			{
				l = (Boolean)Properties[login];
				u = (String)Properties[username];

			}
			else {
				l = false;
				u = null;
			}
			MainPage = new ViewModel();
		}

		protected override void OnStart()
		{
			// Handle when your app starts
		}

		protected override void OnSleep()
		{
			Properties[login] = l;
			Properties[username] = u;
			Properties[phone] = p;
			Properties[choice] = c;
			Properties[password] = pass;
		}

		protected override void OnResume()
		{
			// Handle when your app resumes
		}
	}
}
