﻿using System;
using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace Project
{
	public class SignUpPage : ContentPage

	{
		Entry desiredusername, passwordEntry, reEnterPassword;
		Label messageLabel;
		Button done;
		public SignUpPage()
		{
			var layout = new StackLayout
			{
				Padding = new Thickness(0, Device.OnPlatform(30, 0, 0), 0, 0),
				VerticalOptions = LayoutOptions.CenterAndExpand,
				HorizontalOptions = LayoutOptions.FillAndExpand,

			};


			StackLayout inner = new StackLayout
			{

				BackgroundColor = Color.FromHex("790110"),
				Margin = new Thickness(20, 20, 20, 20),
				Padding = new Thickness(10, 10, 10, 10),
				//VerticalOptions = LayoutOptions.Center,
				//HorizontalOptions = LayoutOptions.FillAndExpand,
			};


			StackLayout usernamelayout = new StackLayout
			{
				Orientation = StackOrientation.Horizontal
			};
			StackLayout passwordlayout = new StackLayout
			{
				Orientation = StackOrientation.Horizontal
			};
			StackLayout repasswordlayout = new StackLayout
			{
				HorizontalOptions = LayoutOptions.FillAndExpand
			};
			Image userImage = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50
			};
			userImage.Source = ImageSource.FromResource("Project.user grey.ico");
			desiredusername = new Entry
			{
				Placeholder = "abc@scu.edu",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Keyboard = Keyboard.Default,
				TextColor = Color.White,
				Text = "",


			};
			desiredusername.Completed += username_Completed;
			usernamelayout.Children.Add(userImage);
			usernamelayout.Children.Add(desiredusername);

			Image keyImage = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50
			};
			Uri keyimageUrl = new Uri("http://www.iconsdb.com/icons/preview/dark-gray/key-6-xxl.png");
			keyImage.Source = ImageSource.FromUri(keyimageUrl);
			passwordEntry = new Entry
			{
				IsPassword = true,
				Placeholder = "X123pass",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Keyboard = Keyboard.Default,
				TextColor = Color.White,
				Text = "",
			};
			passwordlayout.Children.Add(keyImage);
			reEnterPassword = new Entry
			{
				IsPassword = true,
				Placeholder = "X123pass",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Keyboard = Keyboard.Default,
				TextColor = Color.White,
				Text = "",
			};
			reEnterPassword.Completed += rePassword_Completed;
			repasswordlayout.Children.Add(passwordEntry);
			repasswordlayout.Children.Add(reEnterPassword);
			passwordlayout.Children.Add(repasswordlayout);

			messageLabel = new Label
			{
				Text = "Usernmae should be your SCU email id",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				TextColor = Color.FromHex("790110"),
				FontSize = 15,
				FontFamily = "serif"

			};

			done = new Button
			{
				Text = "DONE",
				TextColor = Color.FromHex("790110"),
				HorizontalOptions = LayoutOptions.FillAndExpand,
				BackgroundColor = Color.FromHex("e3e7ed")

			};
			done.Clicked += Password_Completed;

			inner.Children.Add(usernamelayout);
			inner.Children.Add(passwordlayout);
			inner.Children.Add(done);
			layout.Children.Add(inner);
			layout.Children.Add(messageLabel);



			//relative layout starts here
			Image backgroundImage = new Image
			{
				Aspect = Aspect.Fill
			};
			backgroundImage.Source = ImageSource.FromUri(new Uri("http://www.welcomia.com/uploads/preview/gray_art_design_4004.jpg"));

			var relativeLayout = new RelativeLayout();

			relativeLayout.Children.Add(backgroundImage,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			relativeLayout.Children.Add(layout,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			//new ScrollView { Content =
			Content = relativeLayout;



		}
		private void username_Completed(object sender, EventArgs e)
		{
			String username = desiredusername.Text;


			if (username.Equals(""))
			{
				messageLabel.Text = "Username required.";
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}
			else if (!Regex.Match(username, @"^([\w\.\-]+)@scu.edu").Success)
			{
				DisplayAlert("Username not accepted", "Please enter your SCU email id as username.", "Ok");
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}

		}

		private void Password_Completed(object sender, EventArgs e)
		{
			String username = desiredusername.Text;
			String password = passwordEntry.Text;
			String repassword = reEnterPassword.Text;

			if (username.Equals(""))
			{
				//messageLabel.Text = "Username required.";
				DisplayAlert("Username missing", "Please enter your SCU email id as username.", "Ok");
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}
			else if (!Regex.Match(username, @"^([\w\.\-]+)@scu.edu").Success)
			{
				//messageLabel.Text = "Usename should be a valid SCU email id";
				DisplayAlert("Username not accepted", "Usename should be a valid SCU email id.", "Ok");
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}
			else if (password.Equals(""))
			{
				//messageLabel.Text = "password required.";
				DisplayAlert("Password missing", "password required.", "Ok");
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}
			else if (!(password == repassword))
			{
				//messageLabel.Text = "Two password entries do not match.";
				DisplayAlert("Password mismathc", "Two password entries do not match.", "Ok");
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}

			else
			{

				ViewModel vm = new ViewModel();
				Boolean accepted = vm.setUpUser(username, password);
				if (accepted == false)
				{
					DisplayAlert("Sign up failed", "This user alreay exists in the database", "Ok");
					Navigation.PopModalAsync();
					Navigation.PushModalAsync(new LoginPage(vm));
				}
				else
				{
					DisplayAlert("SignUp successfull", "Go ahead and login", "Ok");
					Navigation.PopModalAsync();
					Navigation.PushModalAsync(new LoginPage(vm));
				}
			}
		}
		private void rePassword_Completed(object sender, EventArgs e)
		{
			String password = passwordEntry.Text;
			String repassword = reEnterPassword.Text;


			if (password.Equals(""))
			{
				DisplayAlert("Password needed", "Please enter a password.", "Ok");
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}
			else if (!(password == repassword))
			{
				DisplayAlert("Password mismatch", "Two password entries do not match.", "Ok");
				passwordEntry.Text = "";
				reEnterPassword.Text = "";
			}

		}
	}
}




