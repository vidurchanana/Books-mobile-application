﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace Project
{
	public class BooksSellingPage : ContentPage
	{
		public Entry search;
		List<Books> books;
		TapGestureRecognizer iconTap = new TapGestureRecognizer();
		ViewModel vm;
		StackLayout booksStack, outerStack;
		ScrollView scroll= new ScrollView();
		Label blankbottom, blanktop;
		public BooksSellingPage(List<Books> booksOnSale, ViewModel viewmodel)
		{
			
			books = booksOnSale;
			vm = viewmodel;
			 outerStack = new StackLayout
			{
				//Spacing = 20,
				Padding = new Thickness(0, Device.OnPlatform(30, 5, 5), 0, 0),
				//BackgroundColor = Color.FromHex("e6e8ed"),	
			};

			StackLayout navBarStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				BackgroundColor = Color.FromHex("790110"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			var logo = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri imageUrl = new Uri("http://etc.usf.edu/presentations/extras/letters/varsity_letters/14/23/k-400.png");
			logo.Source = ImageSource.FromUri(imageUrl);
			iconTap.Tapped += OnIconTapGestureRecognizerTapped;


			search = new Entry
			{
				Placeholder = "search for books",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Keyboard = Keyboard.Default,
				TextColor = Color.Black,
				BackgroundColor=Color.White,

			};
			search.Completed += seachBooksAction;
			var mybooksIcon = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri myBooks = new Uri("http://newsroom.uber.com/wp-content/uploads/2014/07/person-icon.png");
			mybooksIcon.Source = ImageSource.FromUri(myBooks);
			mybooksIcon.GestureRecognizers.Add(iconTap);

			navBarStack.Children.Add(logo);
			navBarStack.Children.Add(search);
			navBarStack.Children.Add(mybooksIcon);
			outerStack.Children.Add(navBarStack);

			//--nav bar section ends here----------------------------------

			//blank top
			 blanktop = new Label
			{
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};

			outerStack.Children.Add(blanktop);
			booksStack = new StackLayout
			{
				Spacing = 20,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.FillAndExpand,
				Padding = new Thickness(5, 0, 0, 5),
			};
			foreach (var b in books)
			{
				StackLayout innerStack = addstack(b.name, b.path, b.price, b.author, b.id);
				booksStack.Children.Add(innerStack);
			}


			scroll.Content = booksStack;
			scroll.Orientation = ScrollOrientation.Vertical;
			outerStack.Children.Add(scroll);
			//blank top
			blankbottom = new Label
			{
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.FillAndExpand,
			};
			//outerStack.Children.Add(blankbottom);

			Image backgroundImage = new Image{
				Aspect = Aspect.Fill
			};
			backgroundImage.Source = ImageSource.FromUri(new Uri("http://www.topiphone5wallpapers.com/wp-content/uploads/Background/White%202.jpg"));

			var relativeLayout = new RelativeLayout();

			relativeLayout.Children.Add(backgroundImage,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			relativeLayout.Children.Add(outerStack,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			Content = relativeLayout;
			SizeChanged += OnSizeChanged;
		}


//new functions starts here

		StackLayout addstack(String title, String source, String price, String author, int id) {
			StackLayout outer = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
			};
			var layout = new StackLayout
			{
				Padding = new Thickness(0, 30, 0, 0),
				Spacing = 10,
			};

			var coverImage = new Image
			{

				Aspect = Aspect.Fill,
				WidthRequest = 160,
				HeightRequest = 200

			};
			if (source == null) {
				source = "https://nnp.wustl.edu/img/bookCovers/genericBookCover.jpg";
			}
			Uri imageUrl= new Uri(source);
			coverImage.Source = ImageSource.FromUri(imageUrl);

			Label titleLabel = new Label
			{
				Text = title,
				TextColor = Color.Black,

			};

			Label priceLabel = new Label
			{
				Text = "$"+price,
				TextColor = Color.Black,
			};

			Button buyerinformationButton = new Button
			{
				Text = "Seller information",
				HorizontalOptions = LayoutOptions.CenterAndExpand,
				TextColor = Color.FromHex("790110"),
				FontSize = 15,

				FontFamily = Device.OnPlatform(
					"null",
					"serif",
					"serif"
					),
				BackgroundColor = Color.FromHex("f2f2f2"),
				StyleId = "" + id
			};
			buyerinformationButton.Clicked += OnPreviewButtonClick;
			outer.Children.Add(coverImage);
			layout.Children.Add(titleLabel);
			layout.Children.Add(priceLabel);
			layout.Children.Add(buyerinformationButton);
			outer.Children.Add(layout);
			return outer;
		}
		void OnIconTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			if (vm.loggedin == true)
			{
				Navigation.PopModalAsync();
				Navigation.PushModalAsync(new MyPage(vm.userBooks, vm));
			}
			else
			{ 	Navigation.PopModalAsync();
				Navigation.PushModalAsync(new LoginPage(vm));}
		}
		void seachBooksAction(object sender, EventArgs e)
		{
			String input = search.Text;
			vm.createSeachPage(input); 
		}
		void OnPreviewButtonClick(object sender, EventArgs args)
		{
			var button = (Button)sender;
			int id = int.Parse(button.StyleId);
			vm.getBookPreview(id);
		}
		void OnSizeChanged(object sender, EventArgs e)
		{


			if (Height < Width)
			{
				blanktop.VerticalOptions = LayoutOptions.FillAndExpand;
				booksStack.Orientation = StackOrientation.Horizontal;
				scroll.Orientation = ScrollOrientation.Horizontal;
				outerStack.Children.Add(blankbottom);


			}

			else
			{
				booksStack.Orientation = StackOrientation.Vertical;
				scroll.Orientation = ScrollOrientation.Vertical;
				outerStack.Children.Remove(blankbottom);
				blanktop.VerticalOptions = LayoutOptions.Fill;
			}
				
		}

	}
}

