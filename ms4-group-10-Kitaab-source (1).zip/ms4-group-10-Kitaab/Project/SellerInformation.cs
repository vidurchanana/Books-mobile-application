﻿using System;
using Plugin.Messaging;
using Xamarin.Forms;

namespace Project
{
	public class SellerInfromation : ContentPage
	{
		ViewModel vm;
		Books book;
		TapGestureRecognizer logoTap = new TapGestureRecognizer();
		TapGestureRecognizer iconTap = new TapGestureRecognizer();
		StackLayout buttonstack, bookinfostack;
		Button sendEmail, sendMessage, call;
		public SellerInfromation(Books b, ViewModel viewmodel) //pass the books object here
		{
			vm = viewmodel;
			book = b;
			logoTap.Tapped += OnLogoTapGestureRecognizerTapped;
			iconTap.Tapped += OnIconTapGestureRecognizerTapped;
			StackLayout outerStack = new StackLayout
			{
				Spacing = 20,
				Padding = new Thickness(0, Device.OnPlatform(30, 10, 10), 0, 0),
			};

			StackLayout navBarStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			var logo = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri imageUrl = new Uri("http://etc.usf.edu/presentations/extras/letters/varsity_letters/14/23/k-400.png");
			logo.Source = ImageSource.FromUri(imageUrl);
			logo.GestureRecognizers.Add(logoTap);
			Label nothing = new Label
			{
				Text = " ",
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};
			var mybooksIcon = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri myBooks = new Uri("http://newsroom.uber.com/wp-content/uploads/2014/07/person-icon.png");
			mybooksIcon.Source = ImageSource.FromUri(myBooks);
			navBarStack.Children.Add(logo);
			navBarStack.Children.Add(nothing);
			navBarStack.Children.Add(mybooksIcon);
			outerStack.Children.Add(navBarStack);
			mybooksIcon.GestureRecognizers.Add(iconTap);

			//--nav bar section ends here----------------------------------

			StackLayout outer = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
			};
			var layout = new StackLayout
			{
				Padding = new Thickness(0, 30, 0, 0),
				Spacing = 10,
			};

			var coverImage = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 200,
				HeightRequest = 200

			};
			Uri BookimageUrl = new Uri(b.path);
			coverImage.Source = ImageSource.FromUri(BookimageUrl);

			Label titleLabel = new Label
			{
				Text = b.name,
				TextColor = Color.Black,
				FontSize = 15

			};

			Label priceLabel = new Label
			{
				Text = "$"+b.price,
				TextColor = Color.Black,
				FontSize = 15
			};

			Label ISBNLabel = new Label
			{
				Text ="ISBN:"+ b.ISBN,
				TextColor = Color.Black,
				FontSize = 15
			};

			Label emailLabel = new Label
			{
				Text = b.username,
				TextColor = Color.FromHex("cc002e"),
				FontSize = 15
			};
			Label phoneLabel = new Label
			{
				Text = "Phone No:"+b.phone,
				TextColor = Color.FromHex("cc002e"),
				FontSize = 15
			};


			outer.Children.Add(coverImage);
			layout.Children.Add(titleLabel);
			layout.Children.Add(priceLabel);
			layout.Children.Add(ISBNLabel);
			layout.Children.Add(emailLabel);
			if (book.phone != null && book.phone != "" && book.choice != false)
			{
				layout.Children.Add(phoneLabel);
			}

			outer.Children.Add(layout);
	

			//--book image and price stack ends here------------


			Label description = new Label
			{
				Text = b.description,
				FontSize=15,
				TextColor = Color.Black,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Margin = 30
			};
			bookinfostack = new StackLayout();
			bookinfostack.Children.Add(outer);
			bookinfostack.Children.Add(description);
			outerStack.Children.Add(bookinfostack);
			//Contact button starts here-------------------------
			buttonstack = new StackLayout
			{
				VerticalOptions = LayoutOptions.FillAndExpand,
				HorizontalOptions = LayoutOptions.Center,
			};
			sendEmail = new Button
			{
				WidthRequest = 150,
				Text = "Send Email",
				HorizontalOptions = LayoutOptions.Center,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 15, };
			sendEmail.Clicked += OnButtonClicked;
			sendMessage = new Button
			{
				WidthRequest = 150,
				Text = "Send message",
				HorizontalOptions = LayoutOptions.Center,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 15,
			};
			sendMessage.Clicked += OnButtonClicked;

			call= new Button{
				
				Text = "Call",
				WidthRequest = 150,
				HorizontalOptions = LayoutOptions.Center,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 15,
			};
			call.Clicked += OnButtonClicked;
			buttonstack.Children.Add(sendEmail);
			if (book.phone != null && book.phone !="" && book.choice!=false) { 
				buttonstack.Children.Add(sendMessage);
				buttonstack.Children.Add(call);
			}
			outerStack.Children.Add(buttonstack);

			ScrollView scroll = new ScrollView();
			scroll.Content = outerStack;
			//relative layout starts here
			Image backgroundImage = new Image
			{
				Aspect = Aspect.Fill
			};
			backgroundImage.Source = ImageSource.FromUri(new Uri("http://www.topiphone5wallpapers.com/wp-content/uploads/Background/White%202.jpg"));

			var relativeLayout = new RelativeLayout();

			relativeLayout.Children.Add(backgroundImage,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			relativeLayout.Children.Add(scroll,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			//new ScrollView { Content =
			Content = relativeLayout;
			SizeChanged += OnSizeChanged;
		}
		void OnLogoTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new BooksSellingPage(vm.booksOnSale, vm));
		}
		void OnIconTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new MyPage(vm.userBooks, vm));
		}
		public void OnButtonClicked(object sender, EventArgs args) {
			if (sender == sendEmail) { 
				var emailMessenger = CrossMessaging.Current.EmailMessenger;
				if (emailMessenger.CanSendEmail)
					{
						var email = new EmailMessageBuilder()
						.To(book.username)
						  .Subject("Willing to buy your book")
						  .Body("Hi, can you tell me a place on campus where we can exchange books?")
						  .Build();
						emailMessenger.SendEmail(email);
					}
			}
			if (sender == sendMessage) { 
				var smsMessenger = CrossMessaging.Current.SmsMessenger;
				if (smsMessenger.CanSendSms)
					smsMessenger.SendSms(book.phone, "Hi, I'd like to buy your book");
			}
			if (sender == call) {
				var phoneCallTask = MessagingPlugin.PhoneDialer;
				if (phoneCallTask.CanMakePhoneCall)
					phoneCallTask.MakePhoneCall(book.phone);
			}
		
		}
		void OnSizeChanged(object sender, EventArgs e)
		{
			if (Height < Width)
			{
				buttonstack.Orientation = StackOrientation.Horizontal;
				bookinfostack.Orientation = StackOrientation.Horizontal;

			}
			else {
				buttonstack.Orientation = StackOrientation.Vertical;
				bookinfostack.Orientation = StackOrientation.Vertical;
			}

		}
	}
}

