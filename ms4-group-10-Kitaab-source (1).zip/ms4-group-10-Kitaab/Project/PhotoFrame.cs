﻿using System;

using Xamarin.Forms;

namespace Project
{
	public class PhotoFrame : ContentPage
	{
		public PhotoFrame()
		{
			Content = new StackLayout
			{
				Children = {
					new Label { Text = "Hello ContentPage" }
				}
			};
		}
	}
}

