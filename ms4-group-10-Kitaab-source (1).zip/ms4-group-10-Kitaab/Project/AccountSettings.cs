﻿using System;

using Xamarin.Forms;

namespace Project
{
	public class AccountSettings : ContentPage
	{
		TapGestureRecognizer logoTap = new TapGestureRecognizer();
		TapGestureRecognizer iconTap = new TapGestureRecognizer();
		TapGestureRecognizer myBooksTab = new TapGestureRecognizer();
		TapGestureRecognizer addbookstab = new TapGestureRecognizer();
		ViewModel vm;
		Label gotoAddABookPage;
		Label gotoMyBooksPage;
		int tapcount = 0;
		Button saveChanges, cancel, SignOut;
		Entry currentpasswordentry, newpasswordentry, retypenewpasswordentry, phone;
		Switch phoneswitch;

		public AccountSettings(ViewModel viewmodel)
		{
			vm = viewmodel;
			logoTap.Tapped += OnLogoTapGestureRecognizerTapped;
			iconTap.Tapped += OnIconTapGestureRecognizerTapped;
			myBooksTab.Tapped += OnMyBooksTapGestureRecognizerTapped;
			addbookstab.Tapped += OnAddBooksTapGestureRecognizerTapped;

			StackLayout outerStack = new StackLayout
			{
				Padding = new Thickness(0, Device.OnPlatform(30, 10, 10), 0, 0),
				BackgroundColor = Color.FromHex("f2f2f2"),
			};
			StackLayout optionsTab = new StackLayout
			{
				BackgroundColor = Color.FromHex("660000"),

			};
			StackLayout navBarStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};
			Image logo = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};

			Uri imageUrl = new Uri("http://etc.usf.edu/presentations/extras/letters/varsity_letters/14/23/k-400.png");
			logo.Source = ImageSource.FromUri(imageUrl);
			logo.GestureRecognizers.Add(logoTap);

			Label nothing = new Label
			{
				Text = " ",
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};
			Image mybooksIcon = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri myBooks = new Uri("http://newsroom.uber.com/wp-content/uploads/2014/07/person-icon.png");
			mybooksIcon.Source = ImageSource.FromUri(myBooks);
			mybooksIcon.GestureRecognizers.Add(iconTap);
			navBarStack.Children.Add(logo);
			navBarStack.Children.Add(nothing);
			navBarStack.Children.Add(mybooksIcon);
			optionsTab.Children.Add(navBarStack);

			//--nav bar section ends here----------------------------------

			//The following label appears only when icon is tapped 
			//They vanish when the icon is tapped again
			gotoAddABookPage = new Label
			{
				Text = "Add a Book",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
				FontFamily = Device.OnPlatform(
					"serif",
					"serif",
					"serif"
					),
				TextColor = Color.FromHex("cccccc"),
				IsVisible = false
			};
			gotoAddABookPage.GestureRecognizers.Add(addbookstab);
			gotoMyBooksPage = new Label
			{
				Text = "My Books",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
				FontFamily = Device.OnPlatform(
					"serif",
					"serif",
					"serif"
					),
				TextColor = Color.FromHex("cccccc"),
				IsVisible = false
			};
			gotoMyBooksPage.GestureRecognizers.Add(myBooksTab);

			optionsTab.Children.Add(gotoMyBooksPage);
			optionsTab.Children.Add(gotoAddABookPage);
			outerStack.Children.Add(optionsTab);
          //navbar ends here----------------------------------------------------------------------------

			StackLayout emailStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				Padding = new Thickness(10, 0, 10, 0),
				HorizontalOptions = LayoutOptions.FillAndExpand
			};

			StackLayout passwordStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				Padding = new Thickness(10, 0, 10, 0),
				HorizontalOptions = LayoutOptions.FillAndExpand
			};


			StackLayout currentpasswordStack = new StackLayout                          // Password update - current
			{
				Orientation = StackOrientation.Horizontal,
				Padding = new Thickness(10, 0, 10, 0),
				HorizontalOptions= LayoutOptions.FillAndExpand
			};

			StackLayout newpasswordStack = new StackLayout                              // Password update - new
			{
				Orientation = StackOrientation.Horizontal,
				Padding = new Thickness(10, 0, 10, 0),
				HorizontalOptions = LayoutOptions.FillAndExpand
			};

			StackLayout retypenewpasswordStack = new StackLayout                        // Password update - retype new
			{
				Orientation = StackOrientation.Horizontal,
				Padding = new Thickness(10, 0, 10, 0),
				HorizontalOptions = LayoutOptions.FillAndExpand
			};

			Label emailaddress = new Label
			{
				Text = "Username",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor= Color.Black,
				FontSize=15
			};

			Entry emailaddressentry = new Entry
			{
				Placeholder = vm.username,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center,
				TextColor = Color.Black,
				IsEnabled = false,
			};
			//entry to add phone number

			Label phoneLabel = new Label { 
				Text = "Phone Number",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.Black,
				FontSize = 15
			
			};
			Label message = new Label
			{
				Text = "The buyers will be given this number along with your email id. However, if you disable the switch the number will not be shown.",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.Black,
				FontSize = 15,
				Margin = new Thickness(10, 0, 10, 30)
					

			};

			phone = new Entry
			{
				Text=vm.phone,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.Black,
				IsEnabled = true,
			};

			Button updatephone = new Button
			{
				Text = "Update Phone Numeber",
				HorizontalOptions = LayoutOptions.End,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 13,
				WidthRequest=200

			};
			updatephone.Clicked += UpdatePhoneNo;

			phoneswitch = new Switch { 
				IsToggled= vm.choice
			};
			phoneswitch.Toggled += Onswitchtoggle;

			StackLayout phonestack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Padding = new Thickness(10, 0, 10, 0)
			};

			phonestack.Children.Add(phoneLabel);
			phonestack.Children.Add(phone);
			phonestack.Children.Add(phoneswitch);


			Label password = new Label
			{
				Text = "Update Password:",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.Black,
				FontSize = 15
			};



		 //   Update = new Button
			//{
			//	Text = "Update",
			//	HorizontalOptions = LayoutOptions.Center,
			//	TextColor = Color.FromHex("cc002e"),
			//	BorderColor = Color.FromHex("cc002e"),
			//	FontSize = 15,

			//	FontFamily = Device.OnPlatform("null", "serif", "serif"),
			//};

			//Update.Clicked += OnButtonClicked;

			Label currentpassword = new Label                                       // Label for Current Password
			{
				Text = "Current",
				WidthRequest=100,
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};

			 currentpasswordentry = new Entry                                  // Entry for  Current Password
			{
				Text = "",
				Placeholder = "Password",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.Gray,
				IsEnabled = true,
				IsPassword = true,
			};

			currentpasswordStack.Children.Add(currentpassword);
			currentpasswordStack.Children.Add(currentpasswordentry);

			Label newpassword = new Label                                       // Label for  New Password
			{
				Text = "New ",
				WidthRequest = 100,
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};

			 newpasswordentry = new Entry                                  // Entry for New Password
			{
				Text = "",
				Placeholder = "Password",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.Gray,
				IsEnabled = true,
				IsPassword = true,
			};

			newpasswordStack.Children.Add(newpassword);
			newpasswordStack.Children.Add(newpasswordentry);

			Label retypenewpassword = new Label                                       // Label for Retype New Password
			{
				Text = "Re-Type",
				WidthRequest = 100,
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};

			retypenewpasswordentry = new Entry                                  // Entry for Retype New Password
			{
				Text = "",
				Placeholder = "Password",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.Gray,
				IsEnabled = true,
				IsPassword = true,
			};

			retypenewpasswordStack.Children.Add(retypenewpassword);
			retypenewpasswordStack.Children.Add(retypenewpasswordentry);


			StackLayout buttonStack = new StackLayout { 
				Orientation = StackOrientation.Horizontal,
				HorizontalOptions= LayoutOptions.Center
			};
			saveChanges = new Button                                            // Save Changes Button
			{
				Text = "Save Password",
				WidthRequest= 120,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 15,
				HorizontalOptions = LayoutOptions.Center,
							};

			cancel = new Button                                                 // Cancel Changes Button
			{
				Text = "Cancel",
				WidthRequest = 120,
				HorizontalOptions = LayoutOptions.Center,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 15,

				FontFamily = Device.OnPlatform("null", "serif", "serif"),
			};
			buttonStack.Children.Add(saveChanges);
			buttonStack.Children.Add(cancel);
			
			saveChanges.Clicked += OnButtonClicked;
			cancel.Clicked += OnButtonClicked;

			SignOut = new Button                                                 // Sign Out Button
			{
				Text = "Sign Out",
				WidthRequest = 120,
				HorizontalOptions = LayoutOptions.Center,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 15,

				FontFamily = Device.OnPlatform("null", "serif", "serif"),
			};
			SignOut.Clicked += OnButtonClicked;
			buttonStack.Children.Add(SignOut);
			emailStack.Children.Add(emailaddress);
			emailStack.Children.Add(emailaddressentry);
			passwordStack.Children.Add(password);
			outerStack.Children.Add(emailStack);
			outerStack.Children.Add(phonestack);
			outerStack.Children.Add(updatephone);
			outerStack.Children.Add(message);
			outerStack.Children.Add(phonestack);
			outerStack.Children.Add(passwordStack);
			outerStack.Children.Add(currentpasswordStack);
			outerStack.Children.Add(newpasswordStack);
			outerStack.Children.Add(retypenewpasswordStack);
			outerStack.Children.Add(buttonStack);
		

			Content = new ScrollView { 
			
				Content=outerStack
			};
		}

		private void OnButtonClicked(object sender, EventArgs e)
		{
			
			if (sender == cancel)
			{
				retypenewpasswordentry.Text = "";
				newpasswordentry.Text = "";
				currentpasswordentry.Text = "";
			}
			if (sender == saveChanges) {
				String renewpass = retypenewpasswordentry.Text;
				String newpass=newpasswordentry.Text;
				String current= currentpasswordentry.Text;
				if (current.Equals(""))
				{
					DisplayAlert("Password Missing", "Current password required.", "OK");
				}
				else if (current != vm.password){
					DisplayAlert("Password Incorrect", "Current password is incorrect.", "OK");
					currentpasswordentry.Text = "";

				}
				else if (!(newpass == renewpass))
				{
					DisplayAlert("Password Incorrect", "Two password entries do not match.", "OK");
					retypenewpasswordentry.Text = "";
					newpasswordentry.Text = "";
				}

				else {
					vm.updatePassword(newpass);
					DisplayAlert("passupdate", "Password Updated!", "OK");
				}

			}
			if (sender == SignOut) {
				vm.signOut();
			}
		}

		void OnLogoTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new BooksSellingPage(vm.booksOnSale, vm));
		}
		void OnIconTapGestureRecognizerTapped(object sender, EventArgs args)
		{

			if (tapcount % 2 == 0)
			{
				gotoAddABookPage.IsVisible = true;
				gotoMyBooksPage.IsVisible = true;
			}
			else {
				gotoAddABookPage.IsVisible = false;
				gotoMyBooksPage.IsVisible = false;
			}
			tapcount++;
		}
		void OnMyBooksTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new MyPage(vm.userBooks, vm));
		}
		void OnAddBooksTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new AddABook(vm));

		}
		void UpdatePhoneNo(object sender, EventArgs args) {
			string phoneNo = phone.Text;
			vm.updatephonenumber(phoneNo);
			DisplayAlert("Phone Number Updated", "", "OK");
		}
		void Onswitchtoggle(object sender, ToggledEventArgs args)
		{
			Boolean choice = args.Value;
			vm.updatephonechoice(choice);
		}
	}
}


