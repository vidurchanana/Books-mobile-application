﻿using System;
using System.Text.RegularExpressions;
using Xamarin.Forms;
using Plugin.Messaging;


namespace Project
{
	public class LoginPage : ContentPage
	{
		Entry usernameEntry, passwordEntry;
		Button forgotPassword, signup, LoginButton;
		Label messageLabel;
		ViewModel vm;
		StackLayout inner;
		public LoginPage(ViewModel viewModel)
		{
			vm = viewModel;
			var layout = new StackLayout
			{
				Padding = new Thickness(0, Device.OnPlatform(30, 0, 0), 0, 0),
				VerticalOptions = LayoutOptions.CenterAndExpand,
				HorizontalOptions = LayoutOptions.FillAndExpand,

			};


			inner = new StackLayout
			{

				BackgroundColor = Color.FromHex("790110"),
				Margin = new Thickness(30, 30, 30, 30),
				Padding = new Thickness(10, 10, 10, 10),
				VerticalOptions = LayoutOptions.Center,
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};


			StackLayout usernamelayout = new StackLayout
			{
				Orientation = StackOrientation.Horizontal
			};
			StackLayout passwordlayout = new StackLayout
			{
				Orientation = StackOrientation.Horizontal
			};
			Image userImage = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50
			};
			//Uri imageUrl = new Uri("https://cdn3.iconfinder.com/data/icons/gray-user-toolbar/512/vcard-512.png");
			userImage.Source = ImageSource.FromResource("Project.user grey.ico");
			usernameEntry = new Entry
			{
				Placeholder = "abc@scu.edu",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Keyboard = Keyboard.Default,
				TextColor = Color.Gray,
				Text = "",


			};
			usernameEntry.Completed += username_Completed;
			usernamelayout.Children.Add(userImage);
			usernamelayout.Children.Add(usernameEntry);

			Image keyImage = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50
			};
			Uri keyimageUrl = new Uri("http://www.iconsdb.com/icons/preview/dark-gray/key-6-xxl.png");
			keyImage.Source = ImageSource.FromUri(keyimageUrl);
			passwordEntry = new Entry
			{
				IsPassword = true,
				Placeholder = "X123pass",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				Keyboard = Keyboard.Default,
				TextColor = Color.Gray,
				Text = "",
			};
			passwordlayout.Children.Add(keyImage);
			passwordlayout.Children.Add(passwordEntry);

			forgotPassword = new Button
			{
				Text = "Forgot Password?",
				TextColor = Color.Black,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				IsVisible = false,
				BackgroundColor = Color.FromHex("e3e7ed")

			};
			forgotPassword.Clicked += OnButtonClicked;
			signup = new Button
			{
				Text = "REGISTER",
				TextColor = Color.FromHex("790110"),
				HorizontalOptions = LayoutOptions.FillAndExpand,
				BackgroundColor = Color.FromHex("e3e7ed")

			};
			signup.Clicked += OnButtonClicked;
			messageLabel = new Label
			{
				Text = "Username is your SCU email id",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				TextColor = Color.FromHex("790110"),
				FontSize = 15,
				FontFamily = Device.OnPlatform(
				"serif",
				"serif",
				"serif"
				)

			};

			LoginButton = new Button
			{
				Text = "LOGIN",
				TextColor = Color.FromHex("790110"),
				HorizontalOptions = LayoutOptions.FillAndExpand,
				BackgroundColor = Color.FromHex("e3e7ed")

			};
			LoginButton.Clicked += Password_Completed;

			inner.Children.Add(usernamelayout);
			inner.Children.Add(passwordlayout);
			inner.Children.Add(LoginButton);
			inner.Children.Add(signup);
			inner.Children.Add(forgotPassword);
			layout.Children.Add(inner);
			layout.Children.Add(messageLabel);



			//relative layout starts here
			Image backgroundImage = new Image
			{
				Aspect = Aspect.Fill
			};
			backgroundImage.Source = ImageSource.FromUri(new Uri("http://www.welcomia.com/uploads/preview/gray_art_design_4004.jpg"));

			var relativeLayout = new RelativeLayout();

			relativeLayout.Children.Add(backgroundImage,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			relativeLayout.Children.Add(layout,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			//new ScrollView { Content =
			Content = relativeLayout;
		}
		private void Password_Completed(object sender, EventArgs e)
		{
			String username = usernameEntry.Text;
			String password = passwordEntry.Text;

			if (username.Equals(""))
			{
				DisplayAlert("Username missing!", "Please enter your SCU email id as username", "Ok");
				passwordEntry.Text = "";
			}
			else if (password.Equals(""))
			{
				DisplayAlert("Password missing!", "Please enter a valid password", "Ok");
				passwordEntry.Text = "";
			}
			else
			{
				Boolean allow = vm.verifyPassword(username, password);
				if (allow)
				{
					Navigation.PopModalAsync();
					Navigation.PushModalAsync(vm.mypage);
				}
				else
				{
					DisplayAlert("Login Failed", "Incorrect Username/ password combination.", "Ok");
					passwordEntry.Text = "";
					forgotPassword.IsVisible = true;
				}
			}
		}
		private void username_Completed(object sender, EventArgs e)
		{
			String username = usernameEntry.Text;

			if (username.Equals(""))
			{
				DisplayAlert("Login Failed", "Username required.", "Ok");
				//messageLabel.Text = "Username required.";
				passwordEntry.Text = "";
			}
			else if (!Regex.Match(username, @"^([\w\.\-]+)@scu.edu").Success)
			{
				DisplayAlert("Login Failed", "Username should be a valid SCU email id.", "Ok");
				//messageLabel.Text = "Username should be a valid SCU email id";
				passwordEntry.Text = "";

			}

		}


		public void OnButtonClicked(object sender, EventArgs e)
		{
			if (sender == signup)
			{
				Navigation.PopModalAsync();
				Navigation.PushModalAsync(new SignUpPage());
			}
			if (sender == forgotPassword)
			{
				var emailMessenger = CrossMessaging.Current.EmailMessenger;
				if (emailMessenger.CanSendEmail)
				{
					var email = new EmailMessageBuilder()
					.To("kitaabapp@gmail.com")
					  .Subject("Forgot Password")
					  .Body("Hi, Please reset my password")
					  .Build();
					emailMessenger.SendEmail(email);
				}
			}
		}

	}
}






