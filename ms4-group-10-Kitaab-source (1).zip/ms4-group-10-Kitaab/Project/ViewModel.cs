﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;
using System.Text.RegularExpressions;

namespace Project
{
	public class ViewModel : ContentPage
	{
		public MyPage mypage;
		public IndexPage indexpage;
		public BooksSellingPage sellingpage;
		public Boolean loggedin;
		public String username;
		public String password;
		public Boolean choice = false;
		public String phone ;
		Model m;
		public List<Books> userBooks;
		public List<Books> booksOnSale;
		public List<UsernamePassword> userdata;
		ViewModel vm;

		App app = Application.Current as App;
		public ViewModel()
		{
			//assign loggedin and username from persistance
			m = new Model();
			loggedin = app.l;
			username = app.u;
			phone = app.p;
			choice = app.c;
			password = app.pass;


			indexpage = new IndexPage(this);
			//get books from model and instantiate books selling page
			booksOnSale = m.getBooksOnSale();
			sellingpage = new BooksSellingPage(booksOnSale, this);
			userdata = m.getUsernamePassword();
			//call mainpage function to get the next page
			if (loggedin == true)
			{
				userBooks = m.getUserBooks(username);
				mypage = new MyPage(userBooks, this);
				Navigation.PushModalAsync(mypage);
			}
			else
			{
				Navigation.PushModalAsync(indexpage);
			}
			vm = this;
		}

		//this method is called when the user loggs in
		public Boolean verifyPassword(String user, String pass)
		{

			foreach (UsernamePassword u in userdata)
			{
				if (u.username == user)
				{
					if (u.password != pass)
						return false;
					else
					{
						loggedin = true;
						app.l = true;
						userBooks = m.getUserBooks(user);
						mypage = new MyPage(userBooks, vm);
						username = u.username;
						app.u = username;
						phone = u.phone;
						app.p = phone;
						choice = u.showphone;
						app.c = choice;
						password = pass;
						app.pass = password;
						return true;
					};
				}

			}
			return false;
		}
		public void pushBooksPage()
		{
			Navigation.PushModalAsync(sellingpage);
		}


		public Boolean setUpUser(String username, String password)
		{
			foreach (UsernamePassword u in userdata)
			{
				if (u.username == username)
					return false;
			}
			loggedin = false;
			UsernamePassword user = new UsernamePassword(username, password, "", false);
			userdata.Add(user);
			m.addUserInTheDB(user);
			userBooks = new List<Books>();
			mypage = new MyPage(userBooks, vm);
			return true;
		}
		public void createSeachPage(String input)
		{
			List<Books> searchedBooks = m.getSearchResult(input);
			sellingpage = new BooksSellingPage(searchedBooks, vm);
			sellingpage.search.Text = input;
			Navigation.PushModalAsync(sellingpage);
		}

		public void updatePassword(String newPass)
		{
			password = newPass;
			app.p = password;
			m.updatePassword(username, newPass);
		}
		public List<Books> addNewBooks(String title, String description, String price, String isbn, String source, String path, String author)
		{
			int lastbookindex = booksOnSale.Count - 1;
			int id;
			if (lastbookindex < 0)
			{
				id = 1;
			}
			else {
				 id = booksOnSale[lastbookindex].id + 1;
			}
			Books book = new Books(title, id, price, description, source, path, author, isbn, username, phone, choice);
			booksOnSale.Add(book);
			userBooks.Add(book);
			m.addBooksInTheDB(book);
			mypage = new MyPage(userBooks, vm);
			sellingpage = new BooksSellingPage(booksOnSale, vm);
			return userBooks;
		}

		public Books getBook(int id)
		{
			foreach (var b in booksOnSale)
			{
				if (b.id == id)
					return b;
			}

			return null;
		}

		public void getBookPreview(int id)
		{
			if (loggedin == false)
			{
				
				Navigation.PushModalAsync(new LoginPage(vm));
			}
			else
			{
				Books b = getBook(id);
				if (b == null)
					DisplayAlert("Book Removed", "The book is no longer available", "OK");
				else
				Navigation.PushModalAsync(new SellerInfromation(b, vm));
			}
		}
		public List<Books> removeBook(int id)
		{
			Books b = getBook(id);
			userBooks.Remove(b);
			booksOnSale.Remove(b);
			sellingpage = new BooksSellingPage(booksOnSale, vm);
			m.removeBook(b);
			return userBooks;
		}
		public void navigateToMyPage()
		{
			if (loggedin == true)
				Navigation.PushModalAsync(new MyPage(userBooks, vm));
			else
				Navigation.PushModalAsync(new LoginPage(vm));
		}
		public void signOut()
		{
			loggedin = false;
			app.l = false;
			app.p = "";
			app.u = null;
			app.c = false;
			Navigation.PushModalAsync(new IndexPage(vm));
		}
		public void editBook(String title, String description, String price, String isbn, String source, String path, String author, int bookId)
		{
			Books book = getBook(bookId);
			book.name = title;
			book.description = description;
			book.price = price;
			book.ISBN = isbn;
			book.source = source;
			book.path = path;
			book.author = author;
			m.UpdateBookInfo(book, bookId);
			foreach (var b in booksOnSale)
			{
				if (b.id == bookId)
				{ 
					b.name = title;
					b.description = description;
					b.price = price;
					b.ISBN = isbn;
					b.source = source;
					b.path = path;
					b.author = author;
				}
			}
			foreach (var b in userBooks)
			{
				if (b.id == bookId)
				{
					b.name = title;
					b.description = description;
					b.price = price;
					b.ISBN = isbn;
					b.source = source;
					b.path = path;
					b.author = author;
				}
			}
		
		}
		public void updatephonechoice(Boolean c)
		{
			choice = c;
			app.c = choice;
			foreach (var book in booksOnSale)
			{
				if(book.username==username)
					book.choice = c;
			}
			m.updatephonechoice(userBooks, c, username);
		}
		public void updatephonenumber(string num)
		{
			phone = num;
			app.p = phone;
			foreach (var book in booksOnSale)
			{
				if(book.username==username)
					book.phone = phone;
			}
			m.updatephonenumber(userBooks, phone, username);
		}

	}
}




