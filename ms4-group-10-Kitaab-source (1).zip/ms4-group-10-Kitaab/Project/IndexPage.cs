﻿using System;

using Xamarin.Forms;

namespace Project
{
	public class IndexPage : ContentPage
	{

		Button LogIn, SignUp, ContinueAsGuest;
		ViewModel vm;
		Image backgroundImage;
		StackLayout layout;
		public IndexPage(ViewModel viewmodel)
		{
			
			vm = viewmodel;
			 layout = new StackLayout
			{
				Padding = new Thickness(5, Device.OnPlatform(30, 15, 15), 5, 5),
				VerticalOptions = LayoutOptions.CenterAndExpand,
				HorizontalOptions= LayoutOptions.CenterAndExpand,

			};

			//LogIn BUtton
			LogIn = new Button
			{
				Text = " LOGIN  ",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 20,
			
				FontFamily = Device.OnPlatform(
					"null",
					"serif",
					"serif"
					), 
			
				BackgroundColor = Color.FromHex("e3e7ed"),
			};
			LogIn.Clicked += OnButtonClicked;

			// Sign Up Button
			SignUp = new Button
			{
				Text = " SIGN UP",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				FontSize = 20,
			
				FontFamily = Device.OnPlatform(
					"null",
					"serif",
					"serif"
					),

				BackgroundColor = Color.FromHex("e3e7ed"),
				VerticalOptions = LayoutOptions.FillAndExpand,//Add Color here for Sign Up Button
			};
			SignUp.Clicked += OnButtonClicked;


			//Guest Button
			ContinueAsGuest = new Button
			{
				Text = "Continue as Guest--->",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				BorderWidth = 0,
				VerticalOptions = LayoutOptions.FillAndExpand,
				BackgroundColor = Color.FromHex("e3e7ed"),
				WidthRequest=250

			};
			ContinueAsGuest.Clicked += OnButtonClicked;

			layout.Children.Add(LogIn);
			layout.Children.Add(SignUp);
			layout.Children.Add(ContinueAsGuest);

			SizeChanged += OnSizeChanged;
			 backgroundImage = new Image
			{
				Aspect = Aspect.Fill
			};
			backgroundImage.Source = ImageSource.FromFile("scuImage.png");

			var relativeLayout = new RelativeLayout();

			relativeLayout.Children.Add(backgroundImage,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			relativeLayout.Children.Add(layout,
				Constraint.Constant(0),
				Constraint.Constant(0),
				Constraint.RelativeToParent((parent) => { return parent.Width; }),
				Constraint.RelativeToParent((parent) => { return parent.Height; }));

			//new ScrollView { Content =
			Content = relativeLayout;
		}

		private  void OnButtonClicked(object sender, EventArgs e)
		{
			if (sender == ContinueAsGuest) { 
				Navigation.PushModalAsync(vm.sellingpage);
			}
			if (sender == LogIn) {
				if (vm.loggedin == true)

					Navigation.PushModalAsync(vm.mypage);

				else
					Navigation.PushModalAsync(new LoginPage(vm));
			}
			if (sender == SignUp)
			{
				
				 Navigation.PushModalAsync(new SignUpPage());

			}
		}
		void OnSizeChanged(object sender, EventArgs e)
		{
			if (Height < Width)
			{
				backgroundImage.Source = ImageSource.FromFile("scuImage2.png");
				layout.VerticalOptions = LayoutOptions.End;
			}
			else
			{ backgroundImage.Source = ImageSource.FromFile("scuImage.png"); 
				layout.VerticalOptions = LayoutOptions.Center;
			}

		}
	}
}
