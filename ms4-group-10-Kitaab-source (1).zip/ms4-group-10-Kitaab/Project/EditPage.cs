﻿using System;

using Xamarin.Forms;

namespace Project
{
	public class EditPage : ContentPage
	{
		TapGestureRecognizer logoTap = new TapGestureRecognizer();
		TapGestureRecognizer iconTap = new TapGestureRecognizer();
		TapGestureRecognizer accountsettingtab = new TapGestureRecognizer();
		TapGestureRecognizer myBooksTab = new TapGestureRecognizer();
		ViewModel vm;
		Label gotoMyBooksPage;
		Label gotoAccountSettingsPage;
		int tapcount = 0;
		Entry adtitleentry, isbnentry, imageUrlEntry, priceentry, adauthorEntry;
		Editor addescriptionentry;
		Button saveChanges;
		Books book;
		public EditPage(ViewModel viewmodel, Books book)
		{
			vm = viewmodel;
			this.book = book;
			logoTap.Tapped += OnLogoTapGestureRecognizerTapped;
			iconTap.Tapped += OnIconTapGestureRecognizerTapped;
			accountsettingtab.Tapped += OnAccountSettingsTapGestureRecognizerTapped;
			myBooksTab.Tapped += OnMyBooksTapGestureRecognizerTapped;

			StackLayout outerStack = new StackLayout
			{
				Spacing = 20,
				Padding = new Thickness(0, Device.OnPlatform(30, 10, 10), 0, 0),
				BackgroundColor = Color.FromHex("f2f2f2"),
			};
			StackLayout optionsTab = new StackLayout
			{
				BackgroundColor = Color.FromHex("660000"),

			};
			StackLayout navBarStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};
			Image logo = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};

			Uri imageUrl = new Uri("http://etc.usf.edu/presentations/extras/letters/varsity_letters/14/23/k-400.png");
			logo.Source = ImageSource.FromUri(imageUrl);
			logo.GestureRecognizers.Add(logoTap);

			Label nothing = new Label
			{
				Text = " ",
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};
			Image mybooksIcon = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri myBooks = new Uri("http://newsroom.uber.com/wp-content/uploads/2014/07/person-icon.png");
			mybooksIcon.Source = ImageSource.FromUri(myBooks);
			mybooksIcon.GestureRecognizers.Add(iconTap);
			navBarStack.Children.Add(logo);
			navBarStack.Children.Add(nothing);
			navBarStack.Children.Add(mybooksIcon);
			optionsTab.Children.Add(navBarStack);

			//--nav bar section ends here----------------------------------

			//The following label appears only when icon is tapped 
			//They vanish when the icon is tapped again
			gotoAccountSettingsPage = new Label
			{
				Text = "Account Settings",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
				FontFamily = Device.OnPlatform(
					"serif",
					"serif",
					"serif"
					),
				TextColor = Color.FromHex("cccccc"),
				IsVisible = false
			};
			gotoAccountSettingsPage.GestureRecognizers.Add(accountsettingtab);
			gotoMyBooksPage = new Label
			{
				Text = "My Books",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				HorizontalTextAlignment = TextAlignment.Center,
				FontSize = Device.GetNamedSize(NamedSize.Medium, typeof(Label)),
				FontFamily = Device.OnPlatform(
					"serif",
					"serif",
					"serif"
					),
				TextColor = Color.FromHex("cccccc"),
				IsVisible = false
			};
			gotoMyBooksPage.GestureRecognizers.Add(myBooksTab);

			optionsTab.Children.Add(gotoMyBooksPage);
			optionsTab.Children.Add(gotoAccountSettingsPage);
			outerStack.Children.Add(optionsTab);


			StackLayout submitheader = new StackLayout                                  //Initial Submit (Welcome) header
			{
				Orientation = StackOrientation.Vertical,
				//BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			StackLayout adtitlestack = new StackLayout                                  //Stack for Ad Title
			{
				Orientation = StackOrientation.Horizontal,
				//BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};
			StackLayout adauthorStack = new StackLayout                                  //Stack for Ad Title
			{
				Orientation = StackOrientation.Horizontal,
				//BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			StackLayout addescriptionstack = new StackLayout                                  //Stack for Ad Description
			{
				Orientation = StackOrientation.Horizontal,
				//BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			StackLayout isbnstack = new StackLayout                                  //Stack for ISBN
			{
				Orientation = StackOrientation.Horizontal,
				//BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			StackLayout pricestack = new StackLayout                                  //Stack for Book Price
			{
				Orientation = StackOrientation.Horizontal,
				//BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			StackLayout uploadpicturestack = new StackLayout                                  //Stack for Book Picture
			{
				Orientation = StackOrientation.Vertical,
				//BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			Label submit = new Label
			{
				Text = "Edit your Book Ad",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				//FontSize = 20,
				TextColor = Color.Black,
			};

		
			Label adtitle = new Label                                               // Label for the Ad's Title
			{
				Text = "*Title of the Book:",
				HorizontalOptions = LayoutOptions.Fill,
				//FontSize = 15,
				TextColor = Color.Black
			};

			adtitleentry = new Entry                                          // Entry Box for the Ad's Title
			{
				Text = book.name,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center,
				//HeightRequest = 30,
				//WidthRequest = 100,
				TextColor = Color.Black,
				IsEnabled = true,
				FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label)),

			};
			Label adauthor = new Label                                               // Label for the Ad's Title
			{
				Text = "author:",
				HorizontalOptions = LayoutOptions.Fill,
				//FontSize = 15,
				TextColor = Color.Black
			};

			adauthorEntry = new Entry                                          // Entry Box for the Ad's Title
			{
				Text = book.author,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center,
				//HeightRequest = 30,
				//WidthRequest = 100,
				TextColor = Color.Black,
				IsEnabled = true,
				FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label)),

			};
			Label addescription = new Label                                               // Label for the Ad's Description
			{
				Text = "Ad Description: ",
				HorizontalOptions = LayoutOptions.Fill,
				FontSize = 15,
				TextColor = Color.Black
			};

			addescriptionentry = new Editor                                          // Entry Box for the Ad's Description
			{
				Text = book.description,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center,
				HeightRequest = 100,
				//WidthRequest = 100,
				TextColor = Color.Black,
				IsEnabled = true,
				FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label)),

			};

			Label isbn = new Label                                               // Label for the ISBN
			{
				Text = "ISBN:",
				HorizontalOptions = LayoutOptions.Fill,
				//FontSize = 15,
				TextColor = Color.Black
			};

			isbnentry = new Entry                                          // Entry Box for ISBN
			{
				Text = book.ISBN,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center,
				//HeightRequest = 30,
				TextColor = Color.Black,
				IsEnabled = true,
				FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label)),

			};

			Label pricelabel = new Label                                               // Label for the Book Price
			{
				Text = "* Price:",
				HorizontalOptions = LayoutOptions.Fill,
				//	FontSize = 15,
				TextColor = Color.Black
			};

			priceentry = new Entry                                          // Entry Box for Book Price
			{
				Text = book.price,
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center,
				//HeightRequest = 30,
				TextColor = Color.Black,
				IsEnabled = true,
				FontSize = Device.GetNamedSize(NamedSize.Small, typeof(Label)),

			};


			Label uploadbookpicture = new Label                                    // Label for the Book Picture
			{
				Text = "Add Image Url:",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				//FontSize = 15,
				TextColor = Color.Black
			};

			imageUrlEntry = new Entry                                          // Entry Box for Book Price
			{
				Text = "",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				VerticalOptions = LayoutOptions.Center,
				//HeightRequest = 30,
				TextColor = Color.Black,
				IsEnabled = true,
			};

			//Button choosefile = new Button                                          // Choose file for the upload
			//{
			//	Text = "Choose File",
			//	HorizontalOptions = LayoutOptions.Start,
			//	TextColor = Color.FromHex("cc002e"),
			//	BorderColor = Color.FromHex("cc002e"),
			//	//FontSize = 10,

			//	FontFamily = Device.OnPlatform("null", "serif", "serif"),
			//};

			Label picturefilename = new Label                                    // Label for the Book Picture
			{
				Text = "No file chosen",
				HorizontalOptions = LayoutOptions.FillAndExpand,
				//FontSize = 15,
				TextColor = Color.Black
			};


			saveChanges = new Button                                          // Upload File Button
			{
				Text = "Save Changes",
				HorizontalOptions = LayoutOptions.Center,
				TextColor = Color.FromHex("cc002e"),
				BorderColor = Color.FromHex("cc002e"),
				//FontSize = 10,

				FontFamily = Device.OnPlatform("null", "serif", "serif"),
			};

			saveChanges.Clicked += OnBookSubmission;

			Content = new ScrollView
			{
				Content = outerStack
			};


			submitheader.Children.Add(submit);
			adtitlestack.Children.Add(adtitle);
			adtitlestack.Children.Add(adtitleentry);
			adauthorStack.Children.Add(adauthor);
			adauthorStack.Children.Add(adauthorEntry);
			addescriptionstack.Children.Add(addescription);
			addescriptionstack.Children.Add(addescriptionentry);
			isbnstack.Children.Add(isbn);
			isbnstack.Children.Add(isbnentry);
			pricestack.Children.Add(pricelabel);
			pricestack.Children.Add(priceentry);
			uploadpicturestack.Children.Add(uploadbookpicture);
			uploadpicturestack.Children.Add(imageUrlEntry);
			//uploadpicturestack.Children.Add(choosefile);
			//uploadpicturestack.Children.Add(picturefilename);
			outerStack.Children.Add(submitheader);
			outerStack.Children.Add(adtitlestack);
			outerStack.Children.Add(adauthorStack);
			outerStack.Children.Add(addescriptionstack);
			outerStack.Children.Add(isbnstack);
			outerStack.Children.Add(pricestack);
			outerStack.Children.Add(uploadpicturestack);
			outerStack.Children.Add(saveChanges);
		}
		void OnLogoTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(vm.sellingpage);
		}
		void OnIconTapGestureRecognizerTapped(object sender, EventArgs args)
		{

			if (tapcount % 2 == 0)
			{
				gotoAccountSettingsPage.IsVisible = true;
				gotoMyBooksPage.IsVisible = true;
			}
			else {
				gotoAccountSettingsPage.IsVisible = false;
				gotoMyBooksPage.IsVisible = false;
			}
			tapcount++;
		}
		void OnAccountSettingsTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new AccountSettings(vm));
		}
		void OnMyBooksTapGestureRecognizerTapped(object sender, EventArgs args)
		{
			Navigation.PopModalAsync();
			Navigation.PushModalAsync(new MyPage(vm.userBooks, vm));
		}
		void OnBookSubmission(object sender, EventArgs args)
		{
			String title = adtitleentry.Text;
			String description = addescriptionentry.Text;
			String price = priceentry.Text;
			String isbn = isbnentry.Text;
			String source = "url";
			String path = imageUrlEntry.Text;
			String author = adauthorEntry.Text;
			if (title == "")
			{
				DisplayAlert("Title Missing", "Title is required", "OK");
			}

			else if (price == "")
			{
				DisplayAlert("Price Missing", "Price is required(If you want the book for free, please add 0 as price)", "OK");
			}

			else {
				try
				{
					if (path == "")
						path = book.path;
					double d = double.Parse(price);
					String p = d.ToString("F2");
					price = p;
					vm.editBook(title, description, price, isbn, source, path, author, book.id);
					Navigation.PopModalAsync();
					Navigation.PushModalAsync(new MyPage(vm.userBooks, vm));
				}
				catch
				{
					DisplayAlert("Incorrect Price", "Please enter the price in this format 'XX.XX'", "OK");

				}
			}
		}

	}
}


