﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;
using System.ComponentModel;

namespace Project
{
	[Table("UsernamePassword")]

	public class UsernamePassword
	{

		[PrimaryKey]
		public string username { get; set; }

		public string password { get; set; }

		public string phone { get; set; }

		public bool showphone { get; set; }

		public UsernamePassword() { }

		public UsernamePassword(string username, string password, string phone, bool showphone)
		{
			this.username = username;
			this.password = password;
			this.phone = phone;
			this.showphone = showphone;
		}
	}
}


