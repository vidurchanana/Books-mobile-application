﻿using System;
using System.Collections.Generic;
using SQLite;
using Xamarin.Forms;
using XamarinForms.SQLite.SQLite;

namespace Project
{
	public class Model
	{
		//Declare the SQLite connection
		private readonly SQLiteConnection _sqLiteConnection;

		//has list of all the books on sale
		private List<Books> booksOnSale = new List<Books>();

		//has list of books user has put on sale
		private List<Books> userBooks = new List<Books>();



		//checks for username and password
	//	private String password;

		private List<UsernamePassword> usernamepass = new List<UsernamePassword>();


		public Model()
		{
			_sqLiteConnection = DependencyService.Get<ISQLite>().GetConnection();

			_sqLiteConnection.CreateTable<Books>();
			_sqLiteConnection.DropTable<UsernamePassword>();
			_sqLiteConnection.CreateTable<UsernamePassword>();

			_sqLiteConnection.Delete<Books>(1);
			_sqLiteConnection.Delete<Books>(2);
			_sqLiteConnection.Delete<Books>(3);
			_sqLiteConnection.Delete<Books>(4);
			_sqLiteConnection.Delete<Books>(5);
			_sqLiteConnection.Delete<Books>(6);
			_sqLiteConnection.Delete<Books>(7);
			_sqLiteConnection.Delete<Books>(8);

			//_sqLiteConnection.Delete<UsernamePassword>(1);
			//_sqLiteConnection.Delete<UsernamePassword>(2);

			_sqLiteConnection.Insert(new UsernamePassword
			{
				username = "vchanana@scu.edu",
				password = "123",
				phone = "+16693505966",
				showphone = true
			});

			_sqLiteConnection.Insert(new UsernamePassword
			{
				username = "ppatra@scu.edu",
				password = "123",
				phone = "+16692940038",
				showphone = true
			});


			_sqLiteConnection.Insert(new Books{
				name = "Xamarin Mobile Application Development",
				id = 1,
				price = "29.99",
				description = "Brand new!",
				source = "url",
				path = "https://images-na.ssl-images-amazon.com/images/I/51fHRU5oT%2BL._SX348_BO1,204,203,200_.jpg",
				author = "Dan Hermes",
				ISBN = "9781484202142",
				username = "vchanana@scu.edu",
				phone = "+16693505966",
				choice = true,

			});

			_sqLiteConnection.Insert(new Books
			{
				name = "Xamarin Mobile",
				id = 2,
				price = "19.99",
				description = "Used - 2 months!",
				source = "url",
				path = "https://www.packtpub.com/sites/default/files/9169ot.jpg",
				author = "Mark Reynolds",
				ISBN = "9781783559176",
				username = "vchanana@scu.edu",
				phone = "+16693505966",
				choice = true,

			});

			_sqLiteConnection.Insert(new Books
			{
				name = "Learning Xamarin Studio",
				id = 3,
				price = "15.99",
				description = "Used Book - OBO",
				source = "url",
				path = "https://images-na.ssl-images-amazon.com/images/I/41ZxPzmFLoL.jpg",
				author = "William Smith",
				ISBN = "9781783550821",
				username = "vchanana@scu.edu",
				phone = "+16693505966",
				choice = true,

			});

			_sqLiteConnection.Insert(new Books
			{
				name = "Chicken Soup for the Soul at Work",
				id = 4,
				price = "8.99",
				description = "An year old. Good condition.",
				source = "url",
				path = "http://ecx.images-amazon.com/images/I/51Z1GWkuzRL._SX301_BO1,204,203,200_.jpg",
				author = "Jack Canfield",
				ISBN = "9781453280461",
				username = "vchanana@scu.edu",
				phone = "+16693505966",
				choice = true,

			});

			_sqLiteConnection.Insert(new Books
			{
				name = "The New One Minute Manager",
				id = 5,
				price = "9.99",
				description = "A good read! Giving it out for less money!!",
				source = "url",
				path = "https://upload.wikimedia.org/wikipedia/en/3/3b/The_One_Minute_Manager.jpg",
				author = "Ken Blanchard, Spencer Johnson\n",
				ISBN = "9780062367544",
				username = "ppatra@scu.edu",
				phone = "+16692940038",
				choice = true,

			});

			_sqLiteConnection.Insert(new Books
			{
				name = "Spiritual Awakenings",
				id = 6,
				price = "10.99",
				description = "Giving it out. Fair condition",
				source = "url",
				path = "http://prodimage.images-bn.com/pimages/2940015821819_p0_v1_s192x300.jpg",
				author = "AA Grapevine Inc",
				ISBN = "2940015821819",
				username = "ppatra@scu.edu",
				phone = "+16692940038",
				choice = true,

			});
		}



		public List<Books> getBooksOnSale()                                         //This Function returns all the books
		{
			var alltables = _sqLiteConnection.Table<Books>();

			foreach (var listing in alltables)
			{
				booksOnSale.Add(listing);
			}

			return booksOnSale;
		}

		public List<Books> getUserBooks(String userName)                             //This function returns all the books by specific user
		{

			var alltables = _sqLiteConnection.Table<Books>().Where(i => i.username == userName);
			foreach (var listing in alltables)
			{
				userBooks.Add(listing);
			}
			return userBooks;

		}

		public List<UsernamePassword> getUsernamePassword()                                         //This Function returns all the books
		{
			var alltables = _sqLiteConnection.Table<UsernamePassword>();

			foreach (var listing in alltables)
			{
				usernamepass.Add(listing);
			}

			return usernamepass;
		}

		public List<Books> getSearchResult(String input)
		{
			List<Books> searchBooks = new List<Books>();
			var alltables = _sqLiteConnection.Table<Books>().Where(i => i.name.Contains(input));
			foreach (var listing in alltables)
			{
				searchBooks.Add(listing);
			}
			return searchBooks;

		}

		public void addBooksInTheDB(Books book)
		{
			_sqLiteConnection.Insert(new Books
			{
				id= book.id,
				name = book.name,
				price = book.price,
				description = book.description,
				source = book.source,
				path = book.path,
				author = book.author,
				ISBN = book.ISBN,
				username = book.username,
				phone = book.phone,
				choice=book.choice
			});
		}

		public void UpdateBookInfo(Books b, int id)
		{

			_sqLiteConnection.Update(new Books
			{
				id = b.id,
				name = b.name,
				price = b.price,
				description = b.description,
				source = b.source,
				path = b.path,
				author = b.author,
				ISBN = b.ISBN,
				username = b.username,
				phone = b.phone,
			});
		}

		public void addUserInTheDB(UsernamePassword user)
		{
			_sqLiteConnection.Insert(new UsernamePassword
			{
				username = user.username,
				password = user.password,
				phone = user.phone,
				showphone = user.showphone
			});

		}
		public void updatePassword(String userName, String passord)
		{
			_sqLiteConnection.Update(new UsernamePassword
			{
				username = userName,
				password= passord
			});


		}


		public void removeBook(Books b)
		{
			_sqLiteConnection.Delete<Books>(b.id);
		}
		public void updatephonechoice(List<Books> books, Boolean choice, String username)
		{
			foreach (var book in books)
			{
				_sqLiteConnection.Update(new Books
				{
					id= book.id,
					choice=choice
				});
			}
			_sqLiteConnection.Update(new UsernamePassword
			{
				username= username,
				showphone= choice

			});
		}
		public void updatephonenumber(List<Books> books, String phone, String username)
		{
			foreach (var book in books)
			{
				_sqLiteConnection.Update(new Books
				{
					id = book.id,
					phone = phone
				});
			}
			_sqLiteConnection.Update(new UsernamePassword
			{
				username = username,
				phone= phone
			});

		}
	}
}


