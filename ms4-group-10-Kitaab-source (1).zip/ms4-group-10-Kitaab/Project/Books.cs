﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite;
using System.ComponentModel;

namespace Project
{
	[Table("Books")]

	public class Books
	{
		public string name { get; set; }
		[PrimaryKey]
		public int id { get; set; }
		public string price { get; set; }
		public string description { get; set; }
		public string source { get; set; }
		public string path { get; set; }
		public string author { get; set; }
		public string ISBN { get; set; }
		public string username { get; set; }
		public string phone { get; set; }
		public Boolean choice { get; set; }

		public Books() { }
		public Books(string name, int id, string price, string description, string source, string path, string author, string ISBN, string username, string phone, Boolean choice)
		{
			this.id = id;
			this.name = name;
			this.price = price;
			this.description = description;
			this.source = source;
			this.path = path;
			this.author = author;
			this.ISBN = ISBN;
			this.username = username;
			this.phone = phone;
			this.choice = choice;
		}
	}
}




