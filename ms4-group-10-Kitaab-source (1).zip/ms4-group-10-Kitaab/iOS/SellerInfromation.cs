﻿using System;

using Xamarin.Forms;

namespace Project.iOS
{
	public class SellerInfromation : ContentPage
	{
		public SellerInfromation() //pass the books object here
		{
			var books = new[]{
				new  {booktitle="Java Application", price= "$34.00", author="author1", imageSource= "http://www.kirkk.com/modularity/wp-content/uploads/2009/12/Cover-784x1024.jpg"},

			};
			StackLayout outerStack = new StackLayout
			{
				Spacing = 20,
				Padding = new Thickness(0, Device.OnPlatform(30, 10, 10), 0, 0),
				BackgroundColor = Color.FromHex("f2f2f2"),
			};

			StackLayout navBarStack = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				BackgroundColor = Color.FromHex("660000"),
				Padding = new Thickness(10, 0, 10, 0)
			};

			var logo = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri imageUrl = new Uri("http://etc.usf.edu/presentations/extras/letters/varsity_letters/14/23/k-400.png");
			logo.Source = ImageSource.FromUri(imageUrl);

			Label nothing = new Label
			{
				Text = " ",
				HorizontalOptions = LayoutOptions.FillAndExpand,
			};
			var mybooksIcon = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 50,
				HeightRequest = 50,

			};
			Uri myBooks = new Uri("http://newsroom.uber.com/wp-content/uploads/2014/07/person-icon.png");
			mybooksIcon.Source = ImageSource.FromUri(myBooks);
			navBarStack.Children.Add(logo);
			navBarStack.Children.Add(nothing);
			navBarStack.Children.Add(mybooksIcon);
			outerStack.Children.Add(navBarStack);

			//--nav bar section ends here----------------------------------

			StackLayout outer = new StackLayout
			{
				Orientation = StackOrientation.Horizontal,
				BackgroundColor = Color.FromHex("f2f2f2")
			};
			var layout = new StackLayout
			{
				Padding = new Thickness(0, 30, 0, 0),
				Spacing = 10,
			};

			var coverImage = new Image
			{

				Aspect = Aspect.AspectFit,
				WidthRequest = 160,
				HeightRequest = 160,

			};
			Uri BookimageUrl = new Uri(books[0].imageSource);
			coverImage.Source = ImageSource.FromUri(BookimageUrl);

			Label titleLabel = new Label
			{
				Text = books[0].booktitle,
				TextColor = Color.Black,

			};

			Label priceLabel = new Label
			{
				Text = books[0].price,
				TextColor = Color.Black,
			};

			outer.Children.Add(coverImage);
			layout.Children.Add(titleLabel);
			layout.Children.Add(priceLabel);
			outer.Children.Add(layout);
			outerStack.Children.Add(outer);

			//--book image and price stack ends here------------

			Label email = new Label
			{
				Text = "vidurc@scu.edu",
				TextColor = Color.FromHex("cc002e"),
				VerticalOptions = LayoutOptions.Start,
				HorizontalOptions = LayoutOptions.Start

		};

			Label description = new Label
			{
				Text="Book is in a perfect condition. Please contact me on my email id as soon as you can. ",
				TextColor = Color.Black,
				VerticalOptions = LayoutOptions.FillAndExpand,
				HorizontalOptions = LayoutOptions.FillAndExpand

			};
			outerStack.Children.Add(email);
			outerStack.Children.Add(description);
		}

	}
}

